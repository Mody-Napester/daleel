<section class="w3l-content-12-main">
    <div class="content-12 text-left py-5">

        <div class="container py-md-5 py-4 HomePageContentTabs">

            <div class="content-info-tabs text-center">

                <input id="tab1" type="radio" name="tabs" checked>
                <label class="tabtle"
                       for="tab1">Our Mission</label>

                <input id="tab2" type="radio" name="tabs">
                <label class="tabtle"
                       for="tab2">Our Goals</label>

                <input id="tab3" type="radio" name="tabs">
                <label class="tabtle"
                       for="tab3">Our Vision</label>

                <section id="content1" class="tab-content">
                    <div class="row content12 align-items-center">
                        <div class="col-lg-6 column">
                            <h6 class="content-heading">
                                Powerful Solution for your Startup Business                            </h6>
                            <p class="content-para mb-3">Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.Ea consequuntur illum facere aperiam sequi optio consectetur
                                adipisicing elitFuga, suscipit totam animi consequatur saepe blanditiis.</p>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Atque quidem odit consequuntur ducimus neque, harum eos eligendi maiores ex cum nobis.                            </p>
                        </div>
                        <div class="col-lg-6 column mt-lg-0 mt-4">
                            <img src="../wp-content/themes/execution/assets/images/s3.jpg"
                                 class="img-fluid radius-image" alt="">
                        </div>

                    </div>
                </section>

                <section id="content2" class="tab-content">
                    <div class="row content12 align-items-center">
                        <div class="col-lg-6 column">
                            <h6 class="content-heading">
                                Passion, Dedication and Hard Work                            </h6>
                            <p class="content-para mb-3">Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.Ea consequuntur illum facere aperiam sequi optio consectetur
                                adipisicing elitFuga, suscipit totam animi consequatur saepe blanditiis.</p>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Atque quidem odit consequuntur ducimus neque, harum eos eligendi maiores ex cum nobis.                            </p>
                        </div>
                        <div class="col-lg-6 column mt-lg-0 mt-4">
                            <img src="../wp-content/themes/execution/assets/images/s6.jpg"
                                 class="img-fluid radius-image" alt="">
                        </div>
                    </div>
                </section>

                <section id="content3" class="tab-content">
                    <div class="row content12 align-items-center">
                        <div class="col-lg-6 column">
                            <h6 class="content-heading">
                                Provide awesome services with our tools                            </h6>
                            <p class="content-para mb-3">Lorem ipsum dolor sit amet,Ea consequuntur illum facere aperiam sequi optio consectetur.Ea consequuntur illum facere aperiam sequi optio consectetur
                                adipisicing elitFuga, suscipit totam animi consequatur saepe blanditiis.</p>
                            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Atque quidem odit consequuntur ducimus neque, harum eos eligendi maiores ex cum nobis.                            </p>
                        </div>
                        <div class="col-lg-6 column mt-lg-0 mt-4">
                            <img src="../wp-content/themes/execution/assets/images/s5.jpg" class="img-fluid radius-image" alt="">
                        </div>
                    </div>
                </section>

            </div>

        </div>

    </div>
</section>
