<div class="map-contact ContactPageMap text-center">
    <iframe class="map-w3layouts" src="{{ $resource->map }}" width="100%" height="400" frameborder="0" style="border: 0px;" allowfullscreen=""></iframe>
</div>
