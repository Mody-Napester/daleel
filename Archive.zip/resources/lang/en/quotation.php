<?php

return array (
  'Quotation' => 'Quotation',
  'Quotation_page' => 'Quotation page',
  'Use_this_form_and_send_us_a_message' => 'Use this form and send us a message',
  'Ask_for_quotation' => 'Ask for quotation',
  'text' => 'Over the past 13 years, translation services in the world have increased many different types of translation projects including document translation (legal translation, medical translation, technical translation, financial translation and other translations). We also provide translation websites and software.',
  'Business_Name' => 'Business Name',
  'Email' => 'Email',
  'Phone' => 'Phone',
  'Source_Language' => 'Source Language',
  'Expected_Volume' => 'Expected Volume',
  'Field_of_translation' => 'Field of translation',
  'Attach_a_sample' => 'Attach a sample',
  'Target_Language' => 'Target Language',
  'Write_Message' => 'Write Message',
  'Submit' => 'Submit',
);
