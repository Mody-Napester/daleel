<?php

return array (
  'Your_message_was_sent_successfully' => 'Your message was sent successfully',
  'Error_Please_try_again' => 'Error Please try again',
  'massage_saved' => 'Massage saved',
);
