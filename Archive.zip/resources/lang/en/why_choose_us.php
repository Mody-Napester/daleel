<?php

return array (
  'Our_services' => 'Our passion',
  'Why_Choose_Us' => 'What are we looking forward to?',
  'title1' => 'Our vision',
  'text1' => 'We aim to be a pioneer in the field of translation with diversified services covering the whole region.',
  'title2' => 'Our mission',
  'text2' => 'To establish a database of linguists who are not only experienced in both linguistic and technical backgrounds but are also responsible with their assignments. To apply and maintain rigid QC (quality control) & QA (quality assurance) system. To adopt the latest technologies used in the translation field. To build a long term fruitful business relations with our clients.',
  'text3' => 'Our team members are our greatest asset and this is why we:
Encourage our translators to continually develop their capabilities, skills and behaviours. Create a healthy working environment via enhancing the team spirit among the members. Apply new methods of employment and retention.',
  'title3' => 'Our People',
);
