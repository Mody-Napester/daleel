<?php

return array (
  'Our_Teammates' => 'Our Teammates',
  'Our_Creative_Team' => 'Our Creative Team',
  'hero_details' => 'Our translation team consists of in-house team, freelance translators, linguists, translators, interpreters, proofreaders, quality assurance managers and web programmers with a solid professional background in translation and interpretation.',
);
