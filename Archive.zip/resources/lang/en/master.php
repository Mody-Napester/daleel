<?php

return array (
  'About' => 'About',
  'About_Text_Footer' => 'Daleel is digital marketing company which help your business to grow with our advanced marketing solutions',
  'Site_Links' => 'Site Links',
  'Languages' => 'Languages',
  'Drop_Us_a_Line' => 'Drop Us a Line',
  'Call_Us_Now' => 'Call Us Now',
  'All_Rights_Reserved' => 'All Rights Reserved',
  'email_email' => 
  array (
    'com' => 'info@daleelsolutions.com',
  ),
  'phone_number_010' => '+201001908181',
  'address_text_1' => 'Villa 143 G - South of Academy',
  'address_text_2' => '5th settlement - The third floor',
);
