<?php

return array (
  'Resources' => 'Resources',
  'Resources_page' => 'Resources page',
  'Web_Resources' => 'Web Resources',
  'Our_Best_Resources' => 'Our Best Resources',
);
