<?php

return array (
  'Our_Clients_Testimonials' => 'Our Clients Testimonials',
  'What_People_Say' => 'What People Say',
  'text' => 'We provide high quality translation services to individuals and all types of companies ranging from small businesses to more than 500 companies worldwide.',
);
