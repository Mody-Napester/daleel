<?php

return array (
  'About' => 'About',
  'Careers' => 'Careers',
  'Clients' => 'Clients',
  'Contact' => 'Contact',
  'Home' => 'Home',
  'Quotation' => 'Request a Consult',
  'Services' => 'Solutions',
  'Resources' => 'Resources',
);
