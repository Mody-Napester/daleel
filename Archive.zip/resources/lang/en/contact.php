<?php

return array (
  'Contact' => 'Contact',
  'Contact_page' => 'Contact page',
  'Write_Message' => 'Write Message',
  'Get_in_Touch' => 'Get in Touch',
  'text' => 'Basic Contact Information',
  'Visit_Us' => 'Visit Us',
  'Call_Us' => 'Call Us',
  'Mail_Us' => 'Mail Us',
  'Name' => 'Name',
  'Email' => 'Email',
  'Phone' => 'Phone',
  'Subject' => 'Subject',
  'Message' => 'Message',
  'Submit' => 'Submit',
);
