<?php

return array (
  'Home' => 'Home',
  'Your_browser_does_not_support_HTML5_video' => 'Your browser does not support HTML5 video',
  'Hero_section_data' => 'Daleel is digital marketing agency which provides multiple advanced marketing solutions',
  'Home_2nd_section_title' => 'Welcome to Daleel Solutions Company',
  'Home_2nd_section_text' => 'Daleel is digital marketing company which help your business to grow with our advanced marketing solutions',
  'Home_2nd_section_extra_title1' => 'Best Prices',
  'Home_2nd_section_extra_text1' => 'We have affordable prices for everyone',
  'Home_2nd_section_extra_title2' => 'Top Quality',
  'Home_2nd_section_extra_text2' => 'We have the perfect quality for everyone',
  'Home_3rd_section_title1' => 'Daleel',
  'Home_3rd_section_title2' => 'Marketing Solutions',
  'Home_3rd_section_text1' => 'We have professional team of graphic designers, web developers, creatives specialists in digital advertising',
  'Home_3rd_section_text2' => 'We work nationally and globally',
  'About_page' => 'About page',
  'Hero_section_title' => 'Daleel Solutions',
  'Read_More' => 'Read More',
);
