<?php

return array (
  'Partners' => 'Partners',
);
