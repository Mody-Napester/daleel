<?php

return array (
  'About_us' => 'About us',
  'About_us_text1' => 'Daleel Solutions',
  'About_us_text2' => 'Daleel innovate, prepare and provide adaptable, user-friendly, profitable and all-inclusive solutions to present and future requirements in the digital marketing industry.',
  'About_us_text3' => 'Daleel is digital marketing agency which provides multiple advanced marketing solutions',
);
