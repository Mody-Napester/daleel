<?php

return array (
  'text1' => 'Request a price quote now through the site for free and we will email you',
  'Get_free_quote' => 'Get free quote',
);
