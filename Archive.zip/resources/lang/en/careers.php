<?php

return array (
  'Careers' => 'Careers',
  'Careers_page' => 'Careers page',
  'Please_fill_this_form' => 'Please fill this form',
  'Join_our_team' => 'Join our team',
  'Text' => 'Please fill this form',
  'Name' => 'Name',
  'Email' => 'Email',
  'Phone' => 'Phone',
  'Gender' => 'Gender',
  'Years_of_experience' => 'Years of experience',
  'Language_Pair' => 'Language Pair',
  'Daily_output_capacity' => 'Daily output capacity',
  'Job_Type' => 'Job Type',
  'Speciality' => 'Speciality',
  'Attach_CV' => 'Attach CV',
  'Address' => 'Address',
  'Submit' => 'Submit',
);
