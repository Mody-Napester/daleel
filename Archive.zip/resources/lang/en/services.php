<?php

return array (
  'Services' => 'Our Solutions',
  'Services_page' => 'Our Solutions page',
  'Web_Services' => 'Web Solutions',
  'Our_Best_Services' => 'Our Best Solutions',
  'text' => 'Animation, Articles, Audio, Books, Brochures, Business cards, Catalogs, Certificates, Contracts and agreements, Corporate letters, Dictionaries, E-Learning Courses, Economic/Trade materials, Educational records/documents, Film scripts, Financial statements, Flash files, Financial Statements, Financial Reports, Flyers, Hardware, Help files, Illustrations, Immigration documents, Informed Consents, Labels/Packaging, Letters/Emails, Logo, Manuals, Manuals (employee), Manuals (non-technical), Marketing, Marketing (advertisements), Newsletters, Patents, Policy wordings, Presentations, Scientific , Software, Surveys, User guides, Video, Voice over scripts, Web sites.',
);
