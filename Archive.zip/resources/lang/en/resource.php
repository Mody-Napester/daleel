<?php

return array (
  'Resources' => 'Resources',
);
