<?php

return array (
  'Clients' => 'Clients',
  'Clients_page' => 'Clients page',
  'Our_Best_Clients' => 'Our Best Clients',
  'text' => 'Our clients include large multinational, national organizations as well as individuals. We have entered into corporate contracts with large international companies as HESS Egypt, Dairy Queen as well as national companies i.e El Zahed Group.',
);
