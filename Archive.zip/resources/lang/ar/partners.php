<?php

return array (
  'Partners' => 'الشركاء',
);
