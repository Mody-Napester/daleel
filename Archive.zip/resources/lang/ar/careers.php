<?php

return array (
  'Careers' => 'وظائف',
  'Careers_page' => 'صفحة الوظائف',
  'Join_our_team' => 'انضم إلى فريقنا',
  'Please_fill_this_form' => 'يرجى ملء هذا النموذج',
  'Text' => 'يرجى ملء هذا النموذج',
  'Address' => 'عنوان',
  'Attach_CV' => 'إرفاق السيرة الذاتية',
  'Daily_output_capacity' => 'القدرة الإنتاجية اليومية',
  'Email' => 'بريد إلكتروني',
  'Gender' => 'الجنس',
  'Job_Type' => 'نوع الوظيفة',
  'Language_Pair' => 'زوج اللغة',
  'Name' => 'الاسم',
  'Phone' => 'رقم الهاتف',
  'Speciality' => 'التخصص',
  'Submit' => 'إرسال',
  'Years_of_experience' => 'سنوات الخبرة',
);
