<?php

return array (
  'Our_Best_Resources' => 'المصادر',
  'Resources' => 'المصادر',
  'Resources_page' => 'صفحة المصادر',
  'Web_Resources' => 'المصادر',
);
