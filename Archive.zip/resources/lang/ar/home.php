<?php

return array (
  'Home_2nd_section_extra_title1' => 'أفضل الأسعار',
  'Home_2nd_section_title' => 'مرحبا بكم في شركة دليل سوليوشنز',
  'Home_2nd_section_text' => 'دليل هي شركة تسويق رقمي تساعد عملك على النمو من خلال حلولنا التسويقية المتقدمة',
  'Home_2nd_section_extra_title2' => 'اعلي جودة',
  'Home_2nd_section_extra_text1' => 'لدينا أسعار معقولة للجميع',
  'Home_2nd_section_extra_text2' => 'لدينا الجودة المثالية للجميع',
  'Home_3rd_section_title1' => 'دليل',
  'Home_3rd_section_title2' => 'لخدمات التسويق',
  'Your_browser_does_not_support_HTML5_video' => 'متصفحك لا يدعم فيديو HTML5',
  'Home_3rd_section_text1' => 'لدينا فريق محترف من مصممي الجرافيك ومطوري الويب ومتخصصي التصميمات في الإعلانات الرقمية',
  'Home_3rd_section_text2' => 'نحن نعمل على الصعيد الوطني وعلى مستوى العالم',
  'About_page' => 'صفحة من نحن',
  'Hero_section_data' => 'دليل هي وكالة تسويق رقمي تقدم العديد من الحلول التسويقية المتقدمة',
  'Home' => 'الرئيسية',
  'Hero_section_title' => 'دليل سوليوشنز',
  'Read_More' => 'المزيد',
);
