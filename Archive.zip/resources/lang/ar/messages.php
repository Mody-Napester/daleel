<?php

return array (
  'Error_Please_try_again' => 'خطأ يرجى المحاولة مرة أخرى',
  'Your_message_was_sent_successfully' => 'لقد تم ارسال رسالتك بنجاح',
  'massage_saved' => 'تم حفظ الرسالة',
);
