<?php

return array (
  'Home' => 'الرئيسية',
  'About' => 'من نحن',
  'Services' => 'الخدمات',
  'Clients' => 'العملاء',
  'Quotation' => 'طلب استشارة',
  'Careers' => 'الوظائف',
  'Contact' => 'تواصل معنا',
  'Resources' => 'مصادر',
);
