<?php

return array (
  'Resources' => 'المصادر',
);
