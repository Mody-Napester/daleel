<?php

return array (
  'About' => 'من نحن',
  'About_Text_Footer' => 'دليل هي شركة تسويق رقمي تساعد عملك على النمو من خلال حلولنا التسويقية المتقدمة',
  'All_Rights_Reserved' => 'كل الحقوق محفوظة',
  'Call_Us_Now' => 'اتصل بنا الان',
  'Drop_Us_a_Line' => 'اتصل بنا الان',
  'Languages' => 'اللغات',
  'Site_Links' => 'روابط الموقع',
  'email_email' => 
  array (
    'com' => 'info@daleelsolutions.com',
  ),
  'phone_number_010' => '+201001908181',
  'address_text_1' => 'فيلا 143 ج جنوب الاكاديميه',
  'address_text_2' => 'التجمع الخامس - الدور الثالث',
);
