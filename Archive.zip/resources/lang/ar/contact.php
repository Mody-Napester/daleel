<?php

return array (
  'Call_Us' => 'اتصل بنا',
  'Contact' => 'اتصال',
  'Contact_page' => 'صفحة الاتصال',
  'Email' => 'البريد إلكتروني',
  'Get_in_Touch' => 'ابقى على تواصل',
  'Mail_Us' => 'راسلنا بالبريد الإلكتروني',
  'Message' => 'الرسالة',
  'Name' => 'الاسم',
  'Phone' => 'رقم الهاتف',
  'Subject' => 'الموضوع',
  'Submit' => 'إرسال',
  'Visit_Us' => 'زورنا',
  'Write_Message' => 'اكتب رسالة',
  'text' => 'معلومات الاتصال الأساسية',
);
